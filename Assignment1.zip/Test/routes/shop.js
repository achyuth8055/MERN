const express = require('express')
const router = express.Router()
const path = require('path')
const adminData = require('../routes/admin')

router.get('/',(req,res,next)=>{

    res.sendFile(path.join(__dirname, '../', 'view', 'shop.html'))
    console.log(adminData.products)
   
})

module.exports = router;