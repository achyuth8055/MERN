const http = require('http')
const express = require('express')
const adminData = require('./routes/admin')
const shopRoutes = require('./routes/shop')
const app = express()
const path = require('path')
const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded( { extended: false } ))
app.use(express.static(path.join(__dirname, 'public' )))

app.use('/admin', adminData.router)
app.use(shopRoutes)
app.use((req,res,next)=>{
    res.status(404).sendFile(path.join(__dirname, 'view', '404.html'))
})

app.listen(3000,() => { console.log("running at 3000") })