
exports.error = (req,res,next)=>{
    res.render('404',
    {
        title:'404',
        message:'this 404 page'
    })
}