const Product = require('../model/products')

exports.getAddProduct = (req,res,next) => {
    res.render('admin/add-product',{ 
        title:'admin add-product',
        message:'admin-add-Product'
     })
}

exports.postAddProduct = (req,res,next) => {
    //storing in mongoose logic
    console.log("====================")
    console.log(req.body)
    console.log("====================")

    const {
        title,
        description,
        imageUrl,
        price } = req.body;

    const product = new Product({title,description,imageUrl,price})

    product.save().then(response => {
        console.log(response);
        console.log("Added Sucessful")
        res.redirect('/')
    })
    .catch( err => { console.log(err) })

}

exports.viewProduct = (req,res,next) => {

    const prodId = req.params.productId

    Product.findById(prodId).then(product => {
        res.render('admin/view_product',{

            title:'View Item',
            message:'this is view product',
            product:product
        })

    }).catch(err => { console.log(err) } )


}

exports.getAllProducts = (req,res,next) => {
         
    Product.find()
    .then(prods => {   
    res.render('shop/products',{
        title:'shop',
        message:'display All Products',
        prods: prods
    })

    })
    .catch(err => { console.log(err) } )

}

exports.shopIndex = (req,res,next) => {

        res.render('shop/shop',{title:'index', message:"this is index page"})



}