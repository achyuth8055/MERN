const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const shopData = require('./routes/shop')
const adminData = require('./routes/admin')
const error = require('./routes/error')
const app = express()
app.use(bodyParser.urlencoded({extended:false}))
app.set('view engine', 'ejs')
app.set('views','views')


app.use('/admin',adminData)
app.use(shopData)
app.use(error)

mongoose.connect('mongodb://localhost:27017/shop')
.then(result => {
    app.listen(3000,console.log("running at 3000"))
    console.log('connected.!')
    // console.log(result)
})
.catch( err => {
    console.log(err)
})
