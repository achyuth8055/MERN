const express = require('express')
const router = express.Router()
const shopData = require('../controller/products')
router.get('/',shopData.shopIndex)
router.get('/products',shopData.getAllProducts)
router.get('/products/:productId',shopData.viewProduct)

module.exports = router