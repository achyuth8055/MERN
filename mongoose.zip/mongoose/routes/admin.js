const express = require('express')
const router = express.Router()
const adminData = require('../controller/products')
router.get('/add-product',adminData.getAddProduct)
router.post('/add-product',adminData.postAddProduct)
router.get('/view-product',adminData.viewProduct)
module.exports = router