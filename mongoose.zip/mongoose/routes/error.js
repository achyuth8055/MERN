const express = require('express')
const routes = express.Router()
const err = require('../controller/error')

routes.use(err.error)

module.exports = routes