const mongoose = require('mongoose')

const ProductSchema = new mongoose.Schema({
    title : String,
    imageUrl:String,
    description:String,
    price : { 
        type:Number,
        default:09
    }

})

module.exports = mongoose.model('product',ProductSchema)
